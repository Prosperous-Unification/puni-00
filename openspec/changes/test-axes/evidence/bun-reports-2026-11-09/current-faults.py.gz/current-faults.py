import json,os,subprocess,hashlib
from pathlib import Path
root=Path('/home/df/.codex/worktrees/d6d4/puni-00'); path=root/'apps/twilight-structure/twilight-burokrat/cli/src/cli-parser.ts'; evidence=root/'openspec/changes/test-axes/evidence/bun-reports-2026-11-09'
original=path.read_text(); block="""  typed('inspect-bun-test-reports', 'Inspect the Bun test reports.', {
    repository: operand('REPOSITORY'),
    revision: operand('FULL-SHA'),
    reportAuthority: operand('REPORT-AUTHORITY'),
  }),"""
assert original.count(block)==1
faults=[('arity',block.replace("reportAuthority: operand('REPORT-AUTHORITY')", "reportAuthority: optional(operand('REPORT-AUTHORITY'))"),'malformed CLI operands'),('installed-registration','', 'installed executable')]
receipts=[]
for name,replacement,pattern in faults:
 try:
  path.write_text(original.replace(block,replacement))
  invocation=subprocess.run(['python3','/tmp/wbs08039-nov9-monitor.py','fault-'+name,'bun','--smol','test','./apps/twilight-structure/twilight-burokrat/cli/src/evidence/bun-test-reports.test.ts','--timeout=30000','--test-name-pattern',pattern],cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=1024'})
  log=(evidence/('fault-'+name+'.log')).read_text(); observed=invocation.returncode==1 and '(fail)' in log and 'expect(' in log
  assert observed,(name,log)
  receipts.append({'fault':name,'path':str(path.relative_to(root)),'before':block,'after':replacement,'pattern':pattern,'observedAssertionFailure':observed,'originalSha256':hashlib.sha256(original.encode()).hexdigest()})
 finally:
  path.write_text(original);assert path.read_text()==original
(evidence/'current-faults.json').write_text(json.dumps(receipts,indent=2)+'\n')
