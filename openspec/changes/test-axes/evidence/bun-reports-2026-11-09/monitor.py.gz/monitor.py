import os,sys,time,subprocess,json,signal
from pathlib import Path
root=Path('/home/df/.codex/worktrees/d6d4/puni-00')
evidence=root/'openspec/changes/test-axes/evidence/bun-reports-2026-11-09'
name=sys.argv[1]; cap=int(os.environ.get('WBS_RSS_MIB','1400'))*1024; args=sys.argv[2:]
start=time.monotonic(); peak=0; killed=False
with (evidence/(name+'.log')).open('w') as stream:
 process=subprocess.Popen(args,cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 while process.poll() is None:
  stats={}
  for directory in Path('/proc').iterdir():
   if not directory.name.isdigit(): continue
   try:
    stat=(directory/'stat').read_text(); fields=stat[stat.rfind(')')+2:].split(); rss=int(fields[21])*os.sysconf('SC_PAGE_SIZE')//1024
    stats[int(directory.name)]=(int(fields[1]),rss)
   except (FileNotFoundError,ProcessLookupError,PermissionError): continue
  children={process.pid}
  while True:
   expanded=children|{pid for pid,(parent,rss) in stats.items() if parent in children}
   if expanded==children: break
   children=expanded
  peak=max(peak,sum(stats.get(pid,(0,0))[1] for pid in children))
  if peak>cap:
   killed=True; os.killpg(process.pid,signal.SIGKILL)
  time.sleep(.1)
 code=process.wait()
receipt={'command':args,'cwd':str(root),'exit':code,'seconds':round(time.monotonic()-start,2),'sampledPeakKiB':peak,'capKiB':cap,'killedForMemory':killed}
(evidence/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt)); print((evidence/(name+'.log')).read_text()[-3500:]); sys.exit(code)
