import subprocess,pathlib,os,json
r=pathlib.Path('/tmp/puni-bun-report-inspector-sol-oct17');base=['python3','/tmp/runtime-rss-guard.py'];test='apps/twilight-structure/twilight-burokrat/cli/src/evidence/bun-test-reports.test.ts';runs=[
('focused-final',['bun','--smol','test',test,'--timeout=30000','--test-name-pattern','^(?!.*(?:installed executable|reader selection disagreement))'],900),
('reader-final',['bun','test',test,'--timeout=30000','--test-name-pattern','reader selection disagreement'],900),
('devsync-final',['bun','test','tools/tool-devsync/src/test-levels.test.ts','--timeout=30000'],900),
('shared-final',['bun','test','./libs/shared/domain/test-evidence/src/index.test.ts','--timeout=30000'],900),
('browser-regression',['bun','test','apps/twilight-structure/twilight-burokrat/cli/src/evidence/test-reports.test.ts','--timeout=30000','--test-name-pattern','^(?!.*installed Browser)'],900),
('provenance',['bun','apps/twilight-structure/twilight-burokrat/cli/src/cli.ts','scenario','validate','.','openspec/changes/test-axes/specs/test-axes/spec.md'],900),
('openspec-strict',['bun','/tmp/bunx-1000-@fission-ai/openspec@1.12.0/node_modules/@fission-ai/openspec/bin/openspec.js','validate','test-axes','--strict','--json'],900),
('openspec-all',['bun','/tmp/bunx-1000-@fission-ai/openspec@1.12.0/node_modules/@fission-ai/openspec/bin/openspec.js','validate','--all','--json'],900),
('installed-final',['bun','--smol','test',test,'--timeout=30000','--test-name-pattern','installed executable'],1400),
]
for name,command,cap in runs[3:]:
 with open('/tmp/bun-report-'+name+'-oct17.log','w') as log:s=subprocess.run(base+command,cwd=r,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'RUNTIME_CLOSURE_RSS_MIB':str(cap),'OPENSPEC_TELEMETRY':'0'})
 print(json.dumps({'name':name,'exit':s.returncode,'capMiB':cap,'command':command}),flush=True)
 if s.returncode!=0:raise RuntimeError(name+' failed')
