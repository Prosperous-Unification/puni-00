import pathlib,subprocess,os,json
root=pathlib.Path('/tmp/puni-bun-report-inspector-sol-oct17');p=root/'apps/twilight-structure/twilight-burokrat/cli/src/evidence/bun-test-reports.ts';test='apps/twilight-structure/twilight-burokrat/cli/src/evidence/bun-test-reports.test.ts'
faults=[('digest-shape','const Digest = /^[0-9a-f]{64}$/','const Digest = /^.*$/','missing and malformed closed authority pins'),('revision-shape','revision: /^[0-9a-f]{40}(?:[0-9a-f]{24})?$/','revision: /^.*$/','missing and malformed closed authority pins'),('target-name',"target: 'string>=1'","target: 'string'",'missing and malformed closed authority pins'),('artifact-read',"const artifact = readExternalArtifact(root, path, subject);","const artifact = (() => { try { return readExternalArtifact(root, path, subject); } catch { return { path, bytes: new Uint8Array() }; } })();",'missing and unreadable authority and report')]
receipts=[]
for name,before,after,pattern in faults:
 original=p.read_text();assert original.count(before)==1
 try:
  p.write_text(original.replace(before,after));log=pathlib.Path('/tmp/bun-report-r5-'+name+'-oct17.log')
  with log.open('w') as stream:r=subprocess.run(['python3','/tmp/runtime-rss-guard.py','bun','test',test,'--timeout=30000','--test-name-pattern',pattern],cwd=root,stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,'RUNTIME_CLOSURE_RSS_MIB':'900'})
  observed=r.returncode==1 and '(fail)' in log.read_text() and 'killed' not in log.read_text();receipts.append({'fault':name,'exit':r.returncode,'observed':observed,'log':str(log)}); print(receipts[-1],flush=True);assert observed
 finally:p.write_text(original)
pathlib.Path('/tmp/bun-report-r5-extra-oct17.json').write_text(json.dumps(receipts,indent=2)+'\n')
