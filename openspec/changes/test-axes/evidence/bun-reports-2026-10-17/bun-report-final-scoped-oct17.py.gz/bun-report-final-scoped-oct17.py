import subprocess,pathlib,os,json
r=pathlib.Path('/tmp/puni-bun-report-inspector-sol-oct17')
groups={'cli':['apps/twilight-structure/twilight-burokrat/cli/src/evidence/bun-test-reports.ts','apps/twilight-structure/twilight-burokrat/cli/src/evidence/bun-test-reports.test.ts','apps/twilight-structure/twilight-burokrat/cli/src/cli.ts','apps/twilight-structure/twilight-burokrat/cli/src/bin.ts'],'shared':['libs/shared/domain/test-evidence/src/bun-junit.ts','libs/shared/domain/test-evidence/src/index.ts'],'devsync':['tools/tool-devsync/src/test-levels.ts','tools/tool-devsync/src/test-levels.test.ts']}
files=sum(groups.values(),[])+['libs/shared/domain/test-evidence/README.md','openspec/changes/test-axes/proposal.md','openspec/changes/test-axes/tasks.md','openspec/changes/test-axes/specs/test-axes/spec.md','openspec/scenario-allocations.json']
with open('/tmp/bun-report-format-final-oct17.log','w') as log:
 s=subprocess.run(['python3','/tmp/runtime-rss-guard.py','bunx','--no-install','prettier','--write',*files],cwd=r,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'RUNTIME_CLOSURE_RSS_MIB':'900'});print('format',s.returncode,flush=True);assert s.returncode==0
for name,paths in groups.items():
 with open('/tmp/bun-report-lint-'+name+'-restored-oct17.log','w') as log:
  s=subprocess.run(['python3','/tmp/runtime-rss-guard.py','bunx','--no-install','eslint',*paths],cwd=r,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'RUNTIME_CLOSURE_RSS_MIB':'1100' if name=='cli' else '900','NODE_OPTIONS':'--max-old-space-size=1024'});print('lint',name,s.returncode,flush=True);assert s.returncode==0
