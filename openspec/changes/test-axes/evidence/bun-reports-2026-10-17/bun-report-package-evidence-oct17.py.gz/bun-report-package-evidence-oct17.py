from pathlib import Path
import gzip,json,hashlib,re,subprocess
r=Path('/tmp/puni-bun-report-inspector-sol-oct17');dest=r/'openspec/changes/test-axes/evidence/bun-reports-2026-10-17';dest.mkdir(parents=True,exist_ok=True)
paths=list(Path('/tmp').glob('bun-report-*-oct17.log'))+list(Path('/tmp').glob('bun-report-*-oct17.py'))+[Path('/tmp/bun-report-r5-oct17.json'),Path('/tmp/bun-report-r5-extra-oct17.json'),Path('/tmp/bun-report-real-sqlite-parity-oct17.json'),Path('/tmp/bun-report-narrow-tsconfig-oct17.json'),Path('/tmp/runtime-rss-guard.py'),Path('/tmp/puni-bun-report-real-sqlite-oct17/report.xml'),Path('/tmp/puni-bun-report-real-sqlite-oct17/authority.json')]
manifest=[]
for path in sorted(set(paths)):
 raw=path.read_bytes();name=path.name
 if path.parent.name=='puni-bun-report-real-sqlite-oct17':name='real-sqlite-'+name
 packed=gzip.compress(raw,mtime=0);target=dest/(name+'.gz');target.write_bytes(packed)
 row={'source':str(path),'artifact':target.name,'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'gzipSha256':hashlib.sha256(packed).hexdigest()}
 if path.suffix=='.log':
  lines=raw.decode('utf8').splitlines()
  if lines:
   try:receipt=json.loads(lines[-1])
   except json.JSONDecodeError:receipt=None
   if isinstance(receipt,dict) and 'ceilingBytes' in receipt:row['rssReceipt']=receipt
 manifest.append(row)
prior=json.loads(subprocess.check_output(['git','show','f83139f2cf065c9ea119f3a91395a092076ebd19:openspec/scenario-allocations.json'],cwd=r));current=json.loads((r/'openspec/scenario-allocations.json').read_text());assert current['events'][:len(prior['events'])]==prior['events'];assert len(current['events'])==len(prior['events'])+3
packet={'schemaVersion':1,'baseRevision':'f83139f2cf065c9ea119f3a91395a092076ebd19','allocation':{'preservedEvents':len(prior['events']),'appendedEvents':current['events'][len(prior['events']):]},'watchedFaults':json.loads(Path('/tmp/bun-report-r5-oct17.json').read_text())+json.loads(Path('/tmp/bun-report-r5-extra-oct17.json').read_text()),'artifacts':manifest}
(dest/'proof-manifest.json').write_text(json.dumps(packet,indent=2)+'\n');print(json.dumps({'artifacts':len(manifest),'faults':len(packet['watchedFaults']),'prefix':len(prior['events'])}))
