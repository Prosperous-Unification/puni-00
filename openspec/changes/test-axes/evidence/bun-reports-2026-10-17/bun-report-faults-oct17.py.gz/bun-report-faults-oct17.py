import pathlib,subprocess,os,json,hashlib
root=pathlib.Path('/tmp/puni-bun-report-inspector-sol-oct17')
inspector=root/'apps/twilight-structure/twilight-burokrat/cli/src/evidence/bun-test-reports.ts'
parser=root/'libs/shared/domain/test-evidence/src/bun-junit.ts'
cli=root/'apps/twilight-structure/twilight-burokrat/cli/src/cli.ts'
test='apps/twilight-structure/twilight-burokrat/cli/src/evidence/bun-test-reports.test.ts'
faults=[
('sha',inspector,"if (!/^[0-9a-f]{40}(?:[0-9a-f]{24})?$/.test(revision))","if (false)",'symbolic and annotated'),
('committed',inspector,"if (selected.selection.kind !== 'committed')","if (false)",'reader selection disagreement'),
('selection-revision',inspector,'if (selected.selection.revision !== revision)','if (false)','reader selection disagreement'),
('authority-revision',inspector,'if (authority.revision !== revision)','if (false)','symbolic and annotated'),
('candidate',inspector,'if (authority.candidate !== candidate)','if (false)','candidate manifest and report digest'),
('manifest-path',inspector,'if (authority.projectManifest.path !== `${authority.projectRoot}/project.json`)','if (false)','missing target and manifest substitution'),
('manifest-regular',inspector,"manifestEntry === undefined ||\n    (manifestEntry.mode !== '100644' && manifestEntry.mode !== '100755')",'false','missing malformed and nonregular committed manifests'),
('manifest-digest',inspector,'if (hashBytes(manifestBytes) !== authority.projectManifest.digest)','if (false)','candidate manifest and report digest'),
('target-own',inspector,'if (!Object.hasOwn(targets, authority.target))','if (false)','missing target and manifest substitution'),
('target-shape',inspector,"  recordOf(targets[authority.target], 'Bun report target');",'','malformed selected manifest and project root shapes'),
('report-digest',inspector,'if (hashBytes(report.bytes) !== authority.junit.digest)','if (false)','candidate manifest and report digest'),
('case-path',inspector,'if (!RelativePath.allows(entry.file))','if (false)','missing nonregular and noncanonical source'),
('source-regular',inspector,"sourceEntry === undefined ||\n      (sourceEntry.mode !== '100644' && sourceEntry.mode !== '100755')",'false','missing nonregular and noncanonical source'),
('duplicates',inspector,'if (identities.has(caseId))','if (false)','equal conflicting duplicate identities'),
('path-input',inspector,"if (!isAbsolute(path) || resolve(path) !== path || path.includes('\\0'))",'if (false)','external path aliases'),
('path-canonical',inspector,'if (artifact.path !== path)','if (false)','authority path aliases'),
('utf8',inspector,"new TextDecoder('utf-8', { fatal: true })","new TextDecoder('utf-8')",'malformed UTF8 JSON XML'),
('json',inspector,'return JSON.parse(text) as unknown;','try { return JSON.parse(text) as unknown; } catch { return {}; }','malformed UTF8 JSON XML'),
('schema-version',inspector,"schemaVersion: '1'","schemaVersion: 'number'",'malformed UTF8 JSON XML'),
('schema-outer',inspector,"}).onUndeclaredKey('reject');","}).onUndeclaredKey('ignore');",'malformed UTF8 JSON XML'),
('schema-manifest',inspector,"projectManifest: type({ path: RelativePath, digest: Digest }).onUndeclaredKey('reject')","projectManifest: type({ path: RelativePath, digest: Digest }).onUndeclaredKey('ignore')",'malformed UTF8 JSON XML'),
('schema-junit',inspector,"junit: type({ path: 'string>=1', digest: Digest }).onUndeclaredKey('reject')","junit: type({ path: 'string>=1', digest: Digest }).onUndeclaredKey('ignore')",'malformed UTF8 JSON XML'),
('project-root',inspector,'projectRoot: RelativePath','projectRoot: \'string>=1\'','malformed selected manifest and project root shapes'),
('record-shape',inspector,"if (typeof input !== 'object' || input === null || Array.isArray(input))",'if (false)','malformed selected manifest and project root shapes'),
('manifest-name',inspector,"type({ name: 'string>=1', targets: 'unknown' })","type({ 'name?': 'string>=1', targets: 'unknown' })",'malformed selected manifest and project root shapes'),
('outcomes',parser,'if (hasOutcome)','if (false)','malformed UTF8 JSON XML'),
('devsync-outcomes',parser,'if (hasOutcome)','if (false)','the devsync JUnit surface refuses'),
('outcome-loss',parser,'if (outcome !== undefined)','if (false)','preserve all outcomes'),
('ancestry',parser,'suites.slice(1)','suites.slice(100)','real nested same-leaf'),
('suite-name',parser,'if (suite === undefined)','if (false)','malformed selected manifest and project root shapes'),
('suite-move-identity',inspector,'file, entry.titlePath]','file, entry.name]','real nested same-leaf'),
('case-sort',inspector,'cases.sort((left, right) =>','[].sort((left, right) =>','equal conflicting duplicate identities'),
('certification',inspector,'certifies: false as const','certifies: true as const','preserve all outcomes'),
('authentication',inspector,"authentication: { kind: 'absent' as const }","authentication: { kind: 'authenticated' as const }",'preserve all outcomes'),
('digest',inspector,'observationDigest: hashCanonical(observation)','observationDigest: hashCanonical({ revision })','preserve all outcomes'),
('arity',cli,"if (args.length !== 4)\n      throw new Error(\n        'usage: twilight-burokrat inspect-bun-test-reports", "if (false)\n      throw new Error(\n        'usage: twilight-burokrat inspect-bun-test-reports",'malformed CLI operands'),
]
receipts=[]
for name,path,before,after,pattern in faults:
 original=path.read_text(); assert original.count(before)==1,(name,original.count(before))
 try:
  path.write_text(original.replace(before,after))
  command=['python3','/tmp/runtime-rss-guard.py','bun','test',test,'--timeout=30000','--test-name-pattern',pattern]
  if name=='devsync-outcomes':command[4]='tools/tool-devsync/src/test-levels.test.ts'
  log=pathlib.Path('/tmp/bun-report-r5-'+name+'-oct17.log')
  with log.open('w') as stream: run=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,'RUNTIME_CLOSURE_RSS_MIB':'900'})
  output=log.read_text(); observed=run.returncode==1 and '(fail)' in output and '0 fail' not in output and 'killed' not in output
  receipts.append({'fault':name,'exit':run.returncode,'observed':observed,'log':str(log)})
  print(json.dumps(receipts[-1]),flush=True)
  if not observed: raise RuntimeError(name+' did not produce qualified assertion failure')
 finally:path.write_text(original)
pathlib.Path('/tmp/bun-report-r5-oct17.json').write_text(json.dumps(receipts,indent=2)+'\n')
