import pathlib,json,hashlib,collections,subprocess,xml.etree.ElementTree as E,os
r=pathlib.Path('/tmp/puni-bun-report-inspector-sol-oct17');external=pathlib.Path('/tmp/puni-bun-report-real-sqlite-oct17');o=json.loads(pathlib.Path('/tmp/bun-report-real-sqlite-inspect-final-oct17.log').read_text().splitlines()[0]);prefix=o['projectRoot'];expected=[]
def visit(node,suites):
 if node.tag=='testsuite':suites=suites+[node.get('name')]
 if node.tag=='testcase':expected.append((prefix+'/'+node.get('file'),suites[1:]+[node.get('name')],'failed' if node.find('failure') is not None or node.find('error') is not None else 'skipped' if node.find('skipped') is not None else 'passed'))
 for child in node:visit(child,suites)
visit(E.parse(external/'report.xml').getroot(),[])
actual=[(c['file'],c['titlePath'],c['status']) for c in o['cases']];assert sorted(expected)==sorted(actual);assert len(actual)==1431
payload={k:v for k,v in o.items() if k!='observationDigest'};digest=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()+b'\n').hexdigest();assert digest==o['observationDigest'];assert o['authentication']=={'kind':'absent'} and o['certifies'] is False
assert all(c['level']=={'kind':'unresolved'} and c['isolation']=={'kind':'unresolved'} for c in o['cases'])
sourcePaths={c['file'] for c in o['cases']};assert len(sourcePaths)==104
for path in sourcePaths:
 invocation=subprocess.run(['git','-C',str(r),'ls-tree',o['revision'],'--',path],stdout=subprocess.PIPE,check=True,env={**os.environ,'GIT_NO_REPLACE_OBJECTS':'1'});mode,kind,blob=invocation.stdout.decode().split('\t')[0].split();assert kind=='blob' and mode in ['100644','100755']
 source=subprocess.run(['git','-C',str(r),'cat-file','blob',blob],stdout=subprocess.PIPE,check=True,env={**os.environ,'GIT_NO_REPLACE_OBJECTS':'1'}).stdout
 for case in o['cases']:
  if case['file']==path:assert case['source']=={'mode':mode,'blob':blob,'contentDigest':hashlib.sha256(source).hexdigest()}
failures=[{'file':c['file'],'titlePath':c['titlePath']} for c in o['cases'] if c['status']=='failed'];assert subprocess.run(['git','diff','--quiet',o['revision'],'--',*sorted(sourcePaths)],cwd=r).returncode==0
receipt={'revision':o['revision'],'candidate':o['candidate'],'cases':len(actual),'sources':len(sourcePaths),'outcomes':dict(collections.Counter(c['status'] for c in o['cases'])),'rawDigest':o['junit']['digest'],'observationDigest':digest,'sourcePathsUnchanged':True,'failures':failures,'authentication':o['authentication'],'certifies':o['certifies']};pathlib.Path('/tmp/bun-report-real-sqlite-parity-oct17.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
