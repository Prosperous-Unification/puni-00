import { readFile } from 'node:fs/promises';
import { fleetShellScripts, judgeExecutables, parseIndexEntries, readCheckTools } from '/tmp/puni-reviewed-integration-sol-oct17/tools/tool-fleet/src/check';
function commandsOf(target: unknown): string[] {
  if (typeof target !== 'object' || target === null) return [];
  const options = (target as { options?: unknown }).options;
  if (typeof options !== 'object' || options === null) return [];
  const { command, commands } = options as { command?: unknown; commands?: unknown };
  const out: string[] = [];
  if (typeof command === 'string') out.push(command);
  if (Array.isArray(commands)) {
    for (const entry of commands) {
      if (typeof entry === 'string') out.push(entry);
      else if (typeof entry === 'object' && entry !== null) {
        const nested = (entry as { command?: unknown }).command;
        if (typeof nested === 'string') out.push(nested);
      }
    }
  }
  return out;
}

const entries = parseIndexEntries(Bun.spawnSync(['git','ls-files','-s','-z']).stdout.toString().split('\0').filter(Boolean));
const paths=entries.map(entry=>entry.path);
const targets=[];
for(const path of paths.filter(path=>path.endsWith('/project.json'))){
 const project=JSON.parse(await readFile(path,'utf8'));
 targets.push({project:project.name??path,commands:Object.values(project.targets??{}).flatMap(commandsOf)});
}
const locks=await readCheckTools('tools/tool-fleet/src/check-tools.json');
const failures=judgeExecutables(entries.filter(entry=>entry.mode==='100755').map(entry=>entry.path),targets,fleetShellScripts(paths),locks.uncheckedExecutables);
console.log(JSON.stringify({trackedExecutableCount:entries.filter(entry=>entry.mode==='100755').length,failures},null,2));
process.exit(failures.length===0?0:1);
