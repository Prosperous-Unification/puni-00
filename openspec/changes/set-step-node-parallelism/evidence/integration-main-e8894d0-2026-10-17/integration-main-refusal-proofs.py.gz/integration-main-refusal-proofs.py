from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();source=root/'apps/wbs/fe-01/src/components/wbs/plan-refusal.ts';original=source.read_bytes();text=original.decode();receipts=[]
case="    case 'referenced_by_step_parallel':\n      return refusal.error;\n"
mutations=[]
for function,pattern,count in [('stepRemoveCode','reports retained step parallelism from deleteApi',1),('commandCode','reports retained step parallelism from postApi|completed request before a sparse',2)]:
 start=text.index('function '+function+'(');end=text.index('\nfunction ',start+1);section=text[start:end];assert section.count(case)==1;mutations.append((function,text[:start]+section.replace(case,'',1)+text[end:],pattern,count,'Unexpected response variant: object'))
wording="    referenced_by_step_parallel:\n      'That change cannot be made while the affected steps have individual parallelism overrides.',\n";assert text.count(wording)==1;mutations.append(('wording',text.replace(wording,'',1),'retained step parallelism|completed request before a sparse',3,'AssertionError'))
try:
 for label,changed,pattern,count,diagnostic in mutations:
  source.write_text(changed)
  argv=['bunx','--no-install','vitest','run','--config','vitest.config.ts','src/modules/plan-writer/plan-writer.test.ts','--testNamePattern',pattern,'--no-file-parallelism','--maxWorkers=1','--testTimeout=30000','--hookTimeout=30000']
  completed=subprocess.run(argv,cwd=root/'apps/wbs/fe-01',capture_output=True,text=True,timeout=120)
  output=completed.stdout+completed.stderr;Path('/tmp/integration-main-refusal-mutation-'+label+'.log').write_text(output)
  assert completed.returncode==1,(label,completed.returncode)
  assert diagnostic in output,(label,'wrong diagnostic')
  assert str(count)+' failed' in output,(label,'wrong failed count')
  receipts.append({'fault':label,'argv':argv,'cwd':str(root/'apps/wbs/fe-01'),'sourceSha256':hashlib.sha256(changed.encode()).hexdigest(),'exitCode':completed.returncode,'expectedFailedTests':count,'observedDiagnostic':diagnostic})
finally:
 source.write_bytes(original)
 assert source.read_bytes()==original
 Path('/tmp/integration-main-refusal-mutations.json').write_text(json.dumps({'mutations':receipts,'restoredSha256':hashlib.sha256(original).hexdigest()},indent=2)+'\n')
print('All three independent production-path omissions made the real writer tests fail; exact source restored.')
