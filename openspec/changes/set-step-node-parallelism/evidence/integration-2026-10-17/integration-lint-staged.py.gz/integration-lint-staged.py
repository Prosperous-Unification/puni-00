import json
import subprocess
import sys
from pathlib import Path

BATCH_SIZE = 1


def lint_paths(paths, run, persist):
    unique = list(dict.fromkeys(paths))
    manifest = {
        'receivedArgv': paths,
        'selectedPaths': unique,
        'duplicatePaths': [path for index, path in enumerate(paths) if path in paths[:index]],
        'batchSize': BATCH_SIZE,
        'batches': [],
        'completedPaths': [],
    }
    persist(manifest)
    if not unique:
        manifest['exitCode'] = 64
        persist(manifest)
        print('integration lint: empty selected argv', file=sys.stderr)
        return 64
    for offset in range(0, len(unique), BATCH_SIZE):
        batch = unique[offset:offset + BATCH_SIZE]
        argv = ['bunx', 'eslint', *batch]
        record = {'argv': argv, 'paths': batch}
        manifest['batches'].append(record)
        persist(manifest)
        print('integration lint batch: ' + json.dumps(argv), flush=True)
        code = run(argv)
        record['exitCode'] = code
        if code != 0:
            manifest['exitCode'] = code if code > 0 else 128 - code
            persist(manifest)
            return manifest['exitCode']
        manifest['completedPaths'].extend(batch)
        persist(manifest)
    if manifest['completedPaths'] != unique:
        raise RuntimeError('integration lint selected paths were not checked exactly once')
    manifest['exitCode'] = 0
    persist(manifest)
    return 0


def main():
    manifest_path = Path(__file__).resolve().parent / 'integration-lint-argv.json'

    def persist(manifest):
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')

    return lint_paths(sys.argv[1:], lambda argv: subprocess.run(argv, check=False).returncode, persist)


if __name__ == '__main__':
    sys.exit(main())
