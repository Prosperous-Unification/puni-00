import { parse } from 'yaml';
const base = parse(await Bun.file('lefthook.yml').text());
const actual = parse(await Bun.file('/tmp/integration-batched-effective-hooks.yml').text());
function normalized(config) {
  const cloned = structuredClone(config);
  cloned['pre-commit'].parallel ??= false;
  for (const group of Object.values(cloned)) {
    for (const command of Object.values(group.commands)) {
      for (const key of ['glob', 'exclude']) {
        if (typeof command[key] === 'string') command[key] = [command[key]];
      }
    }
  }
  function ordered(value) {
    if (Array.isArray(value)) return value.map(ordered);
    if (value !== null && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key, ordered(value[key])]));
    return value;
  }
  return JSON.stringify(ordered(cloned));
}
const expected = structuredClone(base);
expected['pre-commit'].parallel = false;
expected['pre-commit'].commands.lint.run = 'python3 /tmp/puni-reviewed-integration-sol-oct17/.git/integration-lint-staged.py {staged_files}';
function assertConfig(config) {
  if (normalized(config) !== normalized(expected)) throw Error('effective config differs beyond the two authorized changes');
}
assertConfig(actual);
console.log('PASS complete normalized config equality; only lint.run and pre-commit.parallel changed');
for (const [label, mutate] of [
  ['extra skip', config => { config['pre-commit'].commands.lint.skip = true; }],
  ['extra group', config => { config['pre-push'] = { commands: {} }; }],
  ['missing job', config => { delete config['pre-commit'].commands['tool-wiki']; }],
]) {
  const poisoned = structuredClone(actual);
  mutate(poisoned);
  let refused = false;
  try { assertConfig(poisoned); } catch { refused = true; }
  if (!refused) throw Error('oracle admitted ' + label);
  console.log('PASS oracle rejects ' + label);
}
