import importlib.util,copy
from pathlib import Path
p=Path('.git/integration-lint-staged.py'); spec=importlib.util.spec_from_file_location('wrapper',p); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def proofs(lint):
 paths=[f'file-{i}.ts' for i in range(10)]
 width=module.BATCH_SIZE
 total=(len(paths)+width-1)//width
 for failing in [None,0,total//2,total-1]:
  calls=[]; snapshots=[]
  def run(argv):
   calls.append(argv)
   return 27 if len(calls)-1==failing else 0
  code=lint(paths+[paths[0]],run,lambda m:snapshots.append(copy.deepcopy(m)))
  assert code==(0 if failing is None else 27)
  expected=total if failing is None else failing+1
  assert len(calls)==expected
  assert [x for argv in calls for x in argv[2:]]==paths[:min(width*expected,10)]
  assert all(argv[:2]==['bunx','eslint'] for argv in calls)
  if failing is None:
   assert snapshots[-1]['completedPaths']==paths
   assert snapshots[-1]['receivedArgv']==paths+[paths[0]]
   assert snapshots[-1]['duplicatePaths']==[paths[0]]
 calls=[]
 assert lint([],lambda argv:calls.append(argv),lambda m:None)==64
 assert calls==[]
proofs(module.lint_paths)
print('PASS: exact argv, ordered complete coverage, duplicate deduplication, first/middle/last failure propagation, empty refusal')
for label,old,new in [('error guard','if code != 0:','if False:'),('empty guard','if not unique:','if False:')]:
 namespace={'__name__':'wrapper_mutation'};exec(compile(p.read_text().replace(old,new,1),str(p),'exec'),namespace)
 try:proofs(namespace['lint_paths'])
 except AssertionError: print('PASS: removed '+label+' makes oracle fail')
 else:raise AssertionError('proof cannot detect '+label)
