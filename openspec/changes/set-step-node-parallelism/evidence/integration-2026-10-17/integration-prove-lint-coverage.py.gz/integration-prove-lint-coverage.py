import hashlib,json,subprocess,sys
from pathlib import Path

root=Path.cwd()
selected=[p for p in subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMR','-z']).decode().split('\0')if p and p.rsplit('.',1)[-1]in ['ts','tsx','js','mjs','cjs']]
hashes={}
for path in selected:
 working=Path(path).read_bytes();indexed=subprocess.check_output(['git','show',':'+path]);assert working==indexed,path
 hashes[path]=hashlib.sha256(working).hexdigest()
baseline=Path('/tmp/integration-selected-source-hashes.json')
if sys.argv[1]=='record':
 baseline.write_text(json.dumps(hashes,indent=2)+'\n');print('recorded exact source/index hashes:',len(hashes));sys.exit(0)
assert hashes==json.loads(baseline.read_text()),'source/index changed during checks'
manifest=json.loads(Path('.git/integration-lint-argv.json').read_text())
assert manifest['receivedArgv']==selected,'selector argv differ'
assert manifest['selectedPaths']==selected
assert manifest['duplicatePaths']==[]
assert manifest['completedPaths']==selected
assert manifest['exitCode']==0
assert len(manifest['batches'])==len(selected)
for path,batch in zip(selected,manifest['batches']):
 assert batch=={'argv':['bunx','eslint',path],'paths':[path],'exitCode':0}
print('PASS exact full argv, each selected path checked once by real ESLint, no duplicates, every exit zero; source/index hashes unchanged:',len(selected))
